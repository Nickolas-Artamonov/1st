if input()=='Вячеслав':
    print('Привет, Вячеслав')
else:
    print('Нет такого имени')
a=input()