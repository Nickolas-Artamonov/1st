if int(input())>7:
    print('Привет')
else:
    print('Меньше либо равно 7(((')
a=input()