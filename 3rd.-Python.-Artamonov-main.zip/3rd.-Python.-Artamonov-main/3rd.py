import random
s=[]
print('Введите количество цифр в массиве')
a=int(input())
print('Введите левую границу массива')
b1=int(input())
print('Введите правую границу массива')
b2=int(input())
for _ in range(a):
    b=random.randint(b1, b2)
    if b%3==0:
        s.append(b)
print('Кратно 3:', *s)
ii=input()